
[ezjscServer]
FunctionList[]=groupdocsviewer

[ezjscServer_groupdocsviewer]
Class=GroupdocsviewerServerCallFunctions
File=extension/groupdocsviewer/classes/groupdocsviewerservercallfunctions.php
//Functions[]=groupdocsviewer
// {*Not a valid ezjscServerRouter argument: &quot;ezjscdemo::search&quot;*}
// {*http://svn.projects.ez.no/ezjscore/trunk/packages/ezjscore_extension/documents/example/ezjscore_demo/FAQ - point 4*}

