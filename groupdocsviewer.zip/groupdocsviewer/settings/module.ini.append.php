<?php /*
[ModuleSettings]
ExtensionRepositories[]=groupdocsviewer
ModuleList[]=groupdocsviewer
*/ ?>