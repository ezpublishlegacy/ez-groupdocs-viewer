<?php /* #?ini charset="iso-8859-1"?
[ExtensionSettings]
DesignExtensions[]=groupdocsviewer

#[StylesheetSettings]
#BackendCSSFileList[]=gdviewer_ezoe.css

[JavaScriptSettings]
JavaScriptList[]=gdviewer.js
*/ ?>